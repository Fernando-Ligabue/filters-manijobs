import PropTypes from "prop-types";
import JobCard from "../JobCard";

const ListedJobs = ({ jobs, setSavedJobs, savedJobs }) => {
    return (
        <div className="w-full flex items-center justify-between flex-wrap mt-8 p-1">
            {!jobs.length && <span className="w-full text-center">Nenhuma vaga encontrada com os filtros selecionados.</span>}
            {jobs.map((job) => {
                return <JobCard key={job.id} job={job} setSavedJobs={setSavedJobs} savedJobs={savedJobs} />;
            })}
        </div>
    );
};

ListedJobs.propTypes = {
    jobs: PropTypes.arrayOf(
        PropTypes.shape({
            id: PropTypes.number.isRequired,
            title: PropTypes.string.isRequired,
            company: PropTypes.string.isRequired,
            location: PropTypes.string.isRequired,
            salary: PropTypes.string.isRequired,
            logo: PropTypes.string.isRequired,
            contractStatus: PropTypes.string.isRequired,
            workStatus: PropTypes.string.isRequired,
            contact: PropTypes.string.isRequired,
            about: PropTypes.string.isRequired,
            description: PropTypes.string.isRequired,
            requirements: PropTypes.string.isRequired,
        })
    ).isRequired,
    setSavedJobs: PropTypes.func.isRequired,
    savedJobs: PropTypes.arrayOf(PropTypes.number).isRequired,
};

export default ListedJobs;
