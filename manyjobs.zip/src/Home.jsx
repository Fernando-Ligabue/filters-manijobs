import { useState } from "react";
import Filters from "./components/Filters";
import { jobs } from "./Data/jobs";
import Searchbar from "./components/Searchbar";
import ListedJobs from "./components/ListedJobs";
import PopularSearches from "./components/PopularSearches";


const Home = () => {
	const [filteredJobs, setFilteredJobs] = useState(jobs);
	const [savedJobs, setSavedJobs] = useState([]);

	const handleFilterChange = (filters) => {
		let filtered = [...jobs];
		if (filters.contractStatus.length > 0) {
			filtered = filtered.filter((job) => filters.contractStatus.includes(job.contractStatus));
		}
		if (filters.workStatus.length > 0) {
			filtered = filtered.filter((job) => filters.workStatus.includes(job.workStatus));
		}

		setFilteredJobs(filtered);
	};

	const handleSearch = (query) => {
		const filtered = jobs.filter(
			(job) => 
				job.title.toLowerCase().includes(query.toLowerCase()) || 
				job.contractStatus.toLowerCase().includes(query.toLowerCase()) || 
				job.workStatus.toLowerCase().includes(query.toLowerCase())
		);
		setFilteredJobs(filtered);
	};

	return (
		<div className="w-full">
			<div id="vagas"  className="w-full mt-12 mb-16">
				<div className="w-full flex md:flex-row flex-col items-start relative md:px-8 px-5 gap-9">
					<Filters
						savedJobs={savedJobs}
						onFilterChange={handleFilterChange}
					/>
					<div className="w-full">
						<Searchbar onSearch={handleSearch} />
						<PopularSearches onSearch={handleSearch} />
						<ListedJobs
							jobs={filteredJobs}
							savedJobs={savedJobs}
							setSavedJobs={setSavedJobs}
						/>
					</div>
				</div>
			</div>
		</div>
	);
};

export default Home;