<?php
namespace Inc;

class Actions {
    public static function onActivate() {
        // Activation code here
    }
}